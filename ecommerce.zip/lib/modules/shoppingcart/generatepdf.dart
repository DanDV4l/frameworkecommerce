import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart';
import 'package:pdf/widgets.dart' as pw;

Future<void> getpdf({required list, required total, required name}) async {
  final pdf = pw.Document();

  pdf.addPage(pw.Page(
      build: (pw.Context context) => pw.Center(
              child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.center,
                  children: [
                pw.Text("eCommerce App - DETALHES DO PEDIDO",
                    style: pw.TextStyle(
                        fontSize: 20, fontWeight: pw.FontWeight.bold)),
                pw.Text(
                  "Recibo em nome de $name\n\n",
                ),
                pw.ListView.builder(
                    itemBuilder: (context, index) {
                      return pw.Container(
                          decoration: const pw.BoxDecoration(
                              border: pw.Border(bottom: pw.BorderSide())),
                          child: pw.Row(
                              mainAxisAlignment:
                                  pw.MainAxisAlignment.spaceBetween,
                              children: [
                                pw.Text(list[index].name,
                                    style: pw.TextStyle(
                                        fontWeight: pw.FontWeight.bold)),
                                pw.Text(
                                    "\n\n\nR\$${list[index].price.toStringAsFixed(2)}")
                              ]));
                    },
                    itemCount: list.length),
                pw.Text("Foi pago o valor total de R\$$total",
                    style: pw.TextStyle(fontWeight: pw.FontWeight.bold))
              ]))));

  PhoneAuthProvider();
  final output = await getTemporaryDirectory();
  final file = File("${output.path}/recibo.pdf");
  await file.writeAsBytes(await pdf.save());
  OpenFile.open("${output.path}/recibo.pdf");
}
