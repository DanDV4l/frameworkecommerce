import 'package:ecommerce/shared/providers/generalprovider.dart';
import 'package:ecommerce/shared/theme/appcolors.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class SearchPage extends StatelessWidget {
  List searchList = [];

  SearchPage({Key? key, required this.searchList}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Resultados da pesquisa..."),
        centerTitle: true,
        backgroundColor: AppColors.primary,
      ),
      body: ListView.builder(
          itemCount: searchList.length,
          itemBuilder: (context, index) {
            return ListTile(
              leading: Image.network(searchList[index].imgURL),
              onTap: () {
                Provider.of<GeneralProvider>(context, listen: false).selected =
                    searchList[index];
                Navigator.pushNamed(context, "/product");
              },
              title: Text(
                "${searchList[index].name.toUpperCase()}",
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
              subtitle: Text(
                "R\$${searchList[index].price.toStringAsFixed(2)}",
                style: const TextStyle(fontSize: 13),
              ),
            );
          }),
    );
  }
}
