class AppImages {
  static const google = "assets/images/google.png";
  static const titleImage = "assets/images/homeImage.jpg";
}
