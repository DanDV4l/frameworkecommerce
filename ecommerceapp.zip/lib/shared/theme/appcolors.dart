import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF9a0ce0);
  static final background = Colors.grey.shade100;
}
